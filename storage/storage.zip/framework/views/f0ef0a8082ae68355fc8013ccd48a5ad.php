<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        [x-cloak] {
            display: none !important
        }
    </style>

    <div class="px-4 py-6 max-w-7xl mx-auto">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-semibold text-amber-900">
                EXPEDIENTE DE
                <?php if(empty($cliente->nombre)): ?>
                    <?php echo e($cliente->razon_social); ?>

                <?php else: ?>
                    <?php echo e($cliente->nombre); ?>

                <?php endif; ?>
            </h2>
            <a href="<?php echo e(route('clientes.index')); ?>" class="text-sm text-amber-600 hover:underline">
                ← Volver a clientes
            </a>
        </div>

        
        <div x-data="{
            tab: 'datos',
            getInitial() {
                const s = new URLSearchParams(window.location.search).get('tab');
                const h = (window.location.hash || '').replace('#', '');
                return s || h || 'datos';
            },
            setUrl(v) {
                const url = new URL(window.location);
                url.searchParams.set('tab', v);
                url.hash = v;
                window.history.replaceState({ tab: v }, '', url);
            },
            init() {
                this.tab = this.getInitial();
                this.$watch('tab', (v) => this.setUrl(v));
                window.addEventListener('popstate', (e) => {
                    if (e.state && e.state.tab) this.tab = e.state.tab;
                    else this.tab = this.getInitial();
                });
            },
            focusables: [],
            move(dir) {
                if (!this.focusables.length) return;
                const current = document.activeElement;
                const i = this.focusables.indexOf(current);
                if (i === -1) return;
                const next = this.focusables[(i + dir + this.focusables.length) % this.focusables.length];
                next?.focus();
            }
        }" x-init="focusables = Array.from($el.querySelectorAll('[role=tab]'));" class="space-y-4">
            
            <nav class="flex space-x-4 border-b pb-2" role="tablist" aria-label="Expediente del cliente">
                <button role="tab" :aria-selected="tab === 'datos'" :tabindex="tab === 'datos' ? 0 : -1"
                    @click="tab = 'datos'" @keydown.arrow-right.prevent="move(1)" @keydown.arrow-left.prevent="move(-1)"
                    :class="tab === 'datos' ? 'font-bold border-b-2 border-amber-800' : ''"
                    class="pb-1 focus:outline-none ">
                    Datos Generales
                </button>

                <button role="tab" :aria-selected="tab === 'fiscales'" :tabindex="tab === 'fiscales' ? 0 : -1"
                    @click="tab = 'fiscales'" @keydown.arrow-right.prevent="move(1)"
                    @keydown.arrow-left.prevent="move(-1)"
                    :class="tab === 'fiscales' ? 'font-bold border-b-2 border-amber-800' : ''"
                    class="pb-1 focus:outline-none ">
                    Datos Fiscales
                </button>

                <button role="tab" :aria-selected="tab === 'contrasenas'" :tabindex="tab === 'contrasenas' ? 0 : -1"
                    @click="tab = 'contrasenas'" @keydown.arrow-right.prevent="move(1)"
                    @keydown.arrow-left.prevent="move(-1)"
                    :class="tab === 'contrasenas' ? 'font-bold border-b-2 border-amber-800' : ''"
                    class="pb-1 focus:outline-none ">
                    Contraseñas
                </button>

                <?php if(auth()->check() && auth()->user()->hasRole('admin_despacho')): ?>
                    <button id="tab-obligaciones" role="tab" :aria-selected="tab === 'obligaciones'"
                        :tabindex="tab === 'obligaciones' ? 0 : -1" @click="tab = 'obligaciones'"
                        @keydown.arrow-right.prevent="move(1)" @keydown.arrow-left.prevent="move(-1)"
                        :class="tab === 'obligaciones' ? 'font-bold border-b-2 border-amber-800' : ''"
                        class="pb-1 focus:outline-none border-b-2
                               <?php echo e($obligacionesCompletadas ? 'text-green-600 border-green-600' : 'text-red-600 border-red-600'); ?>">
                        Asignar Obligaciones
                    </button>
                <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('admin_despacho')): ?>
                    <button id="tab-tareas" role="tab" :aria-selected="tab === 'tareas'"
                        :tabindex="tab === 'tareas' ? 0 : -1" @click="tab = 'tareas'"
                        @keydown.arrow-right.prevent="move(1)" @keydown.arrow-left.prevent="move(-1)"
                        :class="tab === 'tareas' ? 'font-bold border-b-2 border-amber-800' : ''"
                        class="pb-1 focus:outline-none border-b-2
                               <?php echo e($tareasCompletadas ? 'text-green-600 border-green-600' : 'text-yellow-600 border-yellow-600'); ?>">
                        Asignar Tareas
                    </button>
                <?php endif; ?>
            </nav>

            
            <section x-show="tab === 'tareas'" x-cloak x-transition.opacity role="tabpanel"
                aria-labelledby="tab-tareas">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('control.tareas-asignadas-crud', ['cliente' => $cliente]);

$__html = app('livewire')->mount($__name, $__params, 'tareas-' . $cliente->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </section>

            <section x-show="tab === 'obligaciones'" x-cloak x-transition.opacity role="tabpanel"
                aria-labelledby="tab-obligaciones">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('control.obligaciones-asignadas', ['cliente' => $cliente]);

$__html = app('livewire')->mount($__name, $__params, 'obligaciones-' . $cliente->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </section>

            <section x-show="tab === 'fiscales'" x-cloak x-transition.opacity role="tabpanel"
                aria-labelledby="tab-fiscales">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('clientes.datos-fiscales', ['cliente' => $cliente]);

$__html = app('livewire')->mount($__name, $__params, 'fiscales-' . $cliente->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </section>

            <section x-show="tab === 'contrasenas'" x-cloak x-transition.opacity role="tabpanel"
                aria-labelledby="tab-contrasenas">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('clientes.cliente-contrasena', ['cliente' => $cliente]);

$__html = app('livewire')->mount($__name, $__params, 'contrasenas-' . $cliente->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </section>

            <section x-show="tab === 'datos'" x-cloak x-transition.opacity role="tabpanel" aria-labelledby="tab-datos">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('clientes.datos-generales', ['cliente' => $cliente]);

$__html = app('livewire')->mount($__name, $__params, 'datos-' . $cliente->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </section>
        </div>
    </div>

    
    <script>
        document.addEventListener('estado-obligaciones', e => {
            const tab = document.getElementById('tab-obligaciones');
            if (!tab) return;

            if (e.detail.completed) {
                tab.classList.add('text-green-600', 'border-green-600');
                tab.classList.remove('text-red-600', 'border-red-600');
            } else {
                tab.classList.add('text-red-600', 'border-red-600');
                tab.classList.remove('text-green-600', 'border-green-600');
            }
        });

      
document.addEventListener('estado-tareas', e => { 
    const tab = document.getElementById('tab-tareas');
    if (!tab) return;

    // Quita cualquier color previo
    tab.classList.remove(
        'text-green-600','border-green-600',
        'text-red-600','border-red-600',
        'text-yellow-600','border-yellow-600'
    );

    if (e.detail.completed) {
        // ✅ Completado → verde
        tab.classList.add('text-green-600','border-green-600');
    } else {
        // ⚠️ Incompleto → amarillo (coincide con tu clase inicial del Blade)
        tab.classList.add('text-yellow-600','border-yellow-600');
    }
});


    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/clientes/expediente/show.blade.php ENDPATH**/ ?>