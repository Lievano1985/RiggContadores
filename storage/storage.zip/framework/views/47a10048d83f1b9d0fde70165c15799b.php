


 <img src="/img/logo.png" alt="Girl in a jacket" width="500" height="600">

 <?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/components/app-logo.blade.php ENDPATH**/ ?>