<div class="space-y-6">
    <?php
        $vigencia = \Carbon\Carbon::parse($cliente->vigencia); // La fecha de vigencia del cliente
        $hoy = \Carbon\Carbon::now();
        $unMesAntes = $hoy->copy()->addMonth(); // Fecha límite para el mes siguiente
    ?>

    <h1
        class="text-md font-bold  text-right
    <!--[if BLOCK]><![endif]--><?php if($vigencia <= $hoy): ?> text-red-500  <!-- Si la vigencia ya ha pasado -->
    <?php elseif($vigencia <= $unMesAntes): ?> 
        text-red-500  <!-- Si falta un mes o menos para que venza -->
    <?php else: ?> 
        text-gray-800  <!-- Si el contrato sigue vigente --> <?php endif; ?>">
        Vigencia:
        <!--[if BLOCK]><![endif]--><?php if($vigencia <= $hoy): ?>
            Sin vigencia
        <?php else: ?>
            <?php echo e($vigencia->format('d/m/Y')); ?>

        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </h1>
    <div wire:key="modo-<?php echo e($modoKey); ?>">

        <label class="inline-flex items-center cursor-pointer">
            <input type="checkbox" wire:model.live="modoEdicion" class="sr-only peer">
            <div
                class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 dark:peer-focus:ring-amber-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-amber-600 dark:peer-checked:bg-amber-600">
            </div>
            <span class="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Modo edición</span>
        </label>
    </div>

    <!-- Formulario -->
    <form wire:submit.prevent="guardar">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- Nombre comercial -->
            <div>
                <label class="block text-sm font-medium mb-1">Nombre comercial</label>
                <input type="text" wire:model="nombre"
                    class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white "
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?> oninput="this.value = this.value.toUpperCase()" required>

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Razón social -->
            <div>
                <label class="block text-sm font-medium mb-1">Razón social</label>
                <input type="text" wire:model="razon_social"
                    class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?> oninput="this.value = this.value.toUpperCase()" required>

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['razon_social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- RFC -->
            <div>
                <label class="block text-sm font-medium mb-1">RFC</label>
                <input type="text" wire:model="rfc"
                    class=" uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?> oninput="this.value = this.value.toUpperCase()" required>

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- CURP -->
            <div>
                <label class="block text-sm font-medium mb-1">CURP</label>
                <input type="text" wire:model="curp"
                    class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?> oninput="this.value = this.value.toUpperCase()" required>

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['curp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Correo -->
            <div>
                <label class="block text-sm font-medium mb-1">Correo</label>
                <input type="email" wire:model="correo"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Teléfono -->
            <div>
                <label class="block text-sm font-medium mb-1">Teléfono</label>
                <input type="text" wire:model="telefono"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Código postal -->
            <div>
                <label class="block text-sm font-medium mb-1">Código postal</label>
                <input type="text" wire:model="codigo_postal"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['codigo_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Dirección -->
            <div>
                <label class="block text-sm font-medium mb-1">Dirección</label>
                <input type="text" wire:model="direccion"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Tipo de persona -->
            <div>
                <label class="block text-sm font-medium mb-1">Tipo de persona</label>
                <select wire:model.live="tipo_persona"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                    <option value="fisica">Persona Física</option>
                    <option value="moral">Persona Moral</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tipo_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">¿Tiene trabajadores?</label>
                <select wire:model.live="tiene_trabajadores"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tiene_trabajadores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Inicio de obligaciones -->
            <div>
                <label class="block text-sm font-medium mb-1">Inicio de obligaciones</label>
                <input type="date" wire:model="inicio_obligaciones"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['inicio_obligaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Fin de obligaciones -->
            <div>
                <label class="block text-sm font-medium mb-1">Fin de obligaciones</label>
                <input type="date" wire:model="fin_obligaciones"
                    class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                    <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fin_obligaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Contrato -->
            <!--[if BLOCK]><![endif]--><?php if($modoEdicion): ?>
                <div>
                    <label class="block text-sm mb-1">Contrato (PDF)</label>
                    <input type="file" wire:model="archivoContrato" accept="application/pdf"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['archivoContrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <!-- Vigencia -->
                <div>
                    <label class="block text-sm font-medium mb-1">Vigencia</label>
                    <input type="date" wire:model="vigencia"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"
                        <?php if(!$modoEdicion): echo 'disabled'; endif; ?>>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['vigencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
        </div>
    <?php else: ?>
        <!--[if BLOCK]><![endif]--><?php if(in_array($cliente->despacho->politica_almacenamiento, ['storage_only', 'both'])): ?>
            <p class="text-sm text-gray-700 dark:text-gray-300">
                <!--[if BLOCK]><![endif]--><?php if($cliente->contrato): ?>
                    📄 <a href="<?php echo e(Storage::disk('public')->url($cliente->contrato)); ?>" target="_blank"
                        class="text-amber-600 hover:underline">
                        Ver contrato
                    </a>
                    <span class="ml-2 text-xs text-gray-500 dark:text-gray-400">
                        (Vigente hasta:
                        <?php echo e($cliente->vigencia ? \Carbon\Carbon::parse($cliente->vigencia)->format('d/m/Y') : 'Sin vigencia'); ?>)
                    </span>
                <?php else: ?>
                    No hay contrato cargado.
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



        <!--[if BLOCK]><![endif]--><?php if($modoEdicion): ?>
            <div class="mt-6 text-right">
                <button type="submit" class="px-4 py-2 bg-amber-950 text-white rounded hover:bg-amber-700">
                    Guardar
                </button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    </form>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show"
            x-transition:leave="transition ease-in duration-500"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform -translate-y-10"
            class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/clientes/datos-generales.blade.php ENDPATH**/ ?>