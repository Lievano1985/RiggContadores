<div class="bg-white dark:bg-gray-900 text-gray-900 dark:text-white p-6 max-w-3xl mx-auto">
    <h2 class="text-xl font-bold mb-4 text-stone-600">Perfil del Despacho</h2>
    <hr class="my-6 border-gray-300 dark:border-gray-600" />




    <form wire:submit.prevent="actualizar" class="space-y-6">
        <div>
            <h3 class="text-md font-semibold mb-2 text-stone-600">Datos del Despacho</h3>

            <div class="space-y-4">
                <div>
                    <label class="block text-sm mb-1">Nombre</label>
                    <input type="text" wire:model.defer="nombre"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">RFC</label>
                    <input type="text" wire:model.defer="rfc"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">Correo de Contacto</label>
                    <input type="email" wire:model.defer="correo_contacto"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['correo_contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">Teléfono</label>
                    <input type="text" wire:model.defer="telefono_contacto"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telefono_contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">Política de Almacenamiento</label>
                    <select wire:model.live="politica_almacenamiento"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:border-amber-600 focus:outline-none">
                        <option value="storage_only">Solo Laravel Storage</option>
                        <option value="drive_only">Solo Google Drive</option>
                        <option value="both">Ambos</option>
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['politica_almacenamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <!--[if BLOCK]><![endif]--><?php if($mostrarAdvertencia): ?>
                    <div x-data="{ visible: <?php if ((object) ('mostrarAdvertencia') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarAdvertencia'->value()); ?>')<?php echo e('mostrarAdvertencia'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarAdvertencia'); ?>')<?php endif; ?>.live }" x-show="visible" x-transition
                        class="flex justify-between text-yellow-800 dark:text-yellow-300 bg-yellow-100 dark:bg-yellow-800 rounded p-3 shadow-inner mt-2">
                        <p class="self-center"><strong>⚠ Atención:</strong> Cambiar la política de almacenamiento puede
                            afectar la visibilidad de archivos.</p>
                        <strong @click="visible = false" class="text-xl cursor-pointer select-none">&times;</strong>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                <!--[if BLOCK]><![endif]--><?php if($politica_almacenamiento !== 'storage_only'): ?>
                    <div>
                        <label class="block text-sm mb-1">ID Carpeta Drive</label>
                        <input type="text" wire:model.defer="drive_folder_id"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['drive_folder_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <hr class="my-6 border-gray-300 dark:border-gray-600" />

        <div>
            <h3 class="text-md font-semibold mb-2 text-stone-600">Datos del Administrador</h3>

            <div class="space-y-4">
                <div>
                    <label class="block text-sm mb-1">Nombre</label>
                    <input type="text" wire:model.defer="admin_name"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">Correo</label>
                    <input type="email" wire:model.defer="admin_email"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['admin_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block text-sm mb-1">Nueva Contraseña <span
                            class="text-sm text-gray-500">(opcional)</span></label>
                    <input type="password" wire:model.defer="admin_password"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['admin_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <div class="flex justify-end mt-6">
            <button type="submit" class="px-6 py-2 bg-amber-950 text-white rounded hover:bg-stone-700">
                Actualizar
            </button>
        </div>
    </form>
 
<!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
<div
    x-data="{ show: true }"
    x-init="setTimeout(() => show = false, 3000)"
    x-show="show"
    x-transition:leave="transition ease-in duration-500"
    x-transition:leave-start="opacity-100 transform translate-y-0"
    x-transition:leave-end="opacity-0 transform -translate-y-10"
    class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900"
>
 <?php echo e(session('succes')); ?>

</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/despachos/despacho-perfil.blade.php ENDPATH**/ ?>