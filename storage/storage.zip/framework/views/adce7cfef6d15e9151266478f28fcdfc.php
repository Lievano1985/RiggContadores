<div class="p-6 bg-white dark:bg-gray-900 rounded-lg shadow space-y-4">

    <div class="flex justify-between items-center">
        <h2 class="text-xl font-bold text-stone-600">Catálogo de tareas</h2>
        <button wire:click="crear" class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded">
            + Nueva tarea
        </button>
    </div>

    <div class="flex space-x-4 items-center">
        <input type="text" wire:model.debounce.500ms="search" placeholder="Buscar por nombre"
            class="w-1/2 px-3 py-2 border rounded dark:bg-gray-700 dark:text-white" />

        <select wire:model="obligacionFiltro" class="px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
            <option value="">Todas las obligaciones</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obligacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($obligacion->id); ?>"><?php echo e($obligacion->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>
    </div>

    


    <table class="min-w-full divide-y divide-gray-300 dark:divide-gray-700 mt-4">
        <thead class="bg-stone-100 dark:bg-stone-900">
            <tr>
                <th class="px-4 py-2 text-left">Nombre</th>
                <th class="px-4 py-2 text-left">Obligación</th>
                <th class="px-4 py-2 text-center">Activo</th>
                <th class="px-4 py-2 text-center">Acciones</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2"><?php echo e($tarea->nombre); ?></td>
                    <td class="px-4 py-2"><?php echo e($tarea->obligacion->nombre ?? 'General'); ?></td>
                    <td class="px-4 py-2 text-center">

                        <label class="inline-flex items-center cursor-pointer mt-2">
                            <input type="checkbox" wire:click="toggleActivo(<?php echo e($tarea->id); ?>)"
                                <?php echo e($tarea->activo ? 'checked' : ''); ?> class="sr-only peer ">
                            <div
                                class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 dark:peer-focus:ring-amber-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-amber-600 dark:peer-checked:bg-amber-600">
                            </div>
                        </label>
                    </td>
                    <td class="px-4 py-2 text-center">
                        <button wire:click="editar(<?php echo e($tarea->id); ?>)"
                            class="text-blue-600 hover:underline">Editar</button>

                        <button wire:click="confirmarEliminacion(<?php echo e($tarea->id); ?>)"
                            class="text-red-600 hover:underline">
                            Eliminar
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <?php echo e($tareas->links()); ?>


    <!--[if BLOCK]><![endif]--><?php if($modalVisible): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
            <div class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg w-full max-w-md space-y-4">

                <h3 class="text-lg font-bold text-stone-600">
                    <?php echo e($isEditing ? 'Editar tarea' : 'Nueva tarea'); ?>

                </h3>

                <div>
                    <label>Nombre</label>
                    <input type="text" wire:model.defer="form.nombre"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white" />
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label>Descripción</label>
                    <textarea wire:model.defer="form.descripcion" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label>Obligación relacionada (opcional)</label>
                    <select wire:model.defer="form.obligacion_id"
                        class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
                        <option value="">Sin obligación</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obligacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($obligacion->id); ?>"><?php echo e($obligacion->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.obligacion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="flex justify-end space-x-2">
                    <button wire:click="$set('modalVisible', false)"
                        class="bg-gray-300 dark:bg-gray-600 text-black dark:text-white px-4 py-2 rounded">
                        Cancelar
                    </button>
                    <button wire:click="guardar" class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded">
                        Guardar
                    </button>
                </div>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    <?php if (isset($component)) { $__componentOriginal35286cb5f40220d929e1df7cf775f365 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35286cb5f40220d929e1df7cf775f365 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmacion-eliminacion','data' => ['confirmingDelete' => $confirmingDelete,'action' => 'eliminarConfirmada']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirmacion-eliminacion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['confirmingDelete' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($confirmingDelete),'action' => 'eliminarConfirmada']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35286cb5f40220d929e1df7cf775f365)): ?>
<?php $attributes = $__attributesOriginal35286cb5f40220d929e1df7cf775f365; ?>
<?php unset($__attributesOriginal35286cb5f40220d929e1df7cf775f365); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35286cb5f40220d929e1df7cf775f365)): ?>
<?php $component = $__componentOriginal35286cb5f40220d929e1df7cf775f365; ?>
<?php unset($__componentOriginal35286cb5f40220d929e1df7cf775f365); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0d8d3c14ebd2b92d484be47e6c018839 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d8d3c14ebd2b92d484be47e6c018839 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notification','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d8d3c14ebd2b92d484be47e6c018839)): ?>
<?php $attributes = $__attributesOriginal0d8d3c14ebd2b92d484be47e6c018839; ?>
<?php unset($__attributesOriginal0d8d3c14ebd2b92d484be47e6c018839); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d8d3c14ebd2b92d484be47e6c018839)): ?>
<?php $component = $__componentOriginal0d8d3c14ebd2b92d484be47e6c018839; ?>
<?php unset($__componentOriginal0d8d3c14ebd2b92d484be47e6c018839); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/catalogos/tareas-crud.blade.php ENDPATH**/ ?>