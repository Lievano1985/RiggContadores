<div class="p-6 bg-white dark:bg-gray-900 rounded-lg shadow">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold text-stone-600">Tareas Asignadas</h2>
        <div class="flex flex-col items-end space-y-2 mb-4">
            <!--[if BLOCK]><![endif]--><?php if($tareasCompletadas): ?>

            <span class="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">✔ Todas las tareas por obligación asignadas</span>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <button wire:click="crear" class="bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700">
                + Asignar nueva tarea
            </button>
        </div>
        

    </div>
    <table class="min-w-full divide-y divide-gray-300 dark:divide-gray-700 text-sm">
        <thead class="bg-stone-100 dark:bg-stone-900">
            <tr>
                <th class="px-4 py-2 text-left">Tarea</th>
                <th class="px-4 py-2 text-left">Auxiliar</th>
                <th class="px-4 py-2 text-left">Obligación</th>
                <th class="px-4 py-2 text-left">Vencimiento</th>
                <th class="px-4 py-2 text-left">Acciones</th>
            </tr>

        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tareasAsignadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2"><?php echo e($tarea->tareaCatalogo->nombre); ?></td>
                    <td class="px-4 py-2"><?php echo e($tarea->contador->name ?? '-'); ?></td>
                    <td class="px-4 py-2">
                        <?php echo e($tarea->obligacionClientecontador?->obligacion?->nombre ?? 'Sin obligación'); ?>

                    </td>
                    <td class="px-4 py-2"><?php echo e($tarea->fecha_limite); ?></td>
                    <td class="px-4 py-2 space-x-2">
                        <button wire:click="editar(<?php echo e($tarea->id); ?>)"
                            class="text-blue-600 hover:underline">Editar</button>
                        <button wire:click="eliminar(<?php echo e($tarea->id); ?>)"
                            class="text-red-600 hover:underline">Eliminar</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($tareasAsignadas->links()); ?>

    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($modalFormVisible): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-stone-800/70 z-50 p-4">
            <div
                class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg w-full max-w-2xl max-h-[85vh] overflow-y-auto">
                <h3 class="text-lg font-semibold mb-4 text-stone-700">Asignar Tarea</h3>


                <form wire:submit.prevent="guardar" class="space-y-4">
                    <div>
                        <label for="obligacion_id"
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Filtrar por obligación
                        </label>
                        <select id="obligacion_id" wire:model.live="obligacion_id"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <option value="">Sin obligación</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligacionesAsignadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pivot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pivot->id); ?>">
                                    <?php echo e($pivot->obligacion->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>


                    </div>


                    
                    <div>
                        <label class="block text-sm mb-1 text-stone-600 dark:text-gray-300">
                            Tarea (catálogo)
                            <span class="text-xs text-gray-500">
                                <!--[if BLOCK]><![endif]--><?php if($obligacion_id): ?>
                                    — Mostrando ligadas a la obligación o sin obligación
                                <?php else: ?>
                                    — Mostrando solo sin obligación
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </span>
                        </label>

                        <select wire:model.defer="tarea_catalogo_id"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <option value="">Seleccione una tarea</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tareasDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>">
                                    <?php echo e($t->nombre); ?>

                                    <!--[if BLOCK]><![endif]--><?php if(is_null($t->obligacion_id)): ?>
                                        (sin obligación)
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>

                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tarea_catalogo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div>
                        <label class="block text-sm mb-1">Auxiliar asignado</label>
                        <select wire:model.defer="contador_id"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <option value="">Selecciona un Auxiliar</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contador_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>



                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm mb-1">Fecha de Asignación</label>
                            <input type="date" wire:model="fecha_asignacion"
                                min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" max="<?php echo e($fechaLimiteMaxima); ?>"
                                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_asignacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div>
                            <label class="block text-sm mb-1">Fecha de Vencimiento</label>
                            <input type="date" wire:model="fecha_limite"
                                min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" max="<?php echo e($fechaLimiteMaxima); ?>"
                                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_limite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>


                    <div>
                        <label class="block text-sm mb-1">Tiempo estimado (minutos)</label>
                        <input type="number" wire:model.defer="tiempo_estimado" min="1" max="1440"
                            placeholder="Ej. 60"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tiempo_estimado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    
                    <div x-data="{
                        abiertos: {},
                        seleccion: <?php if ((object) ('carpeta_drive_id') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('carpeta_drive_id'->value()); ?>')<?php echo e('carpeta_drive_id'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('carpeta_drive_id'); ?>')<?php endif; ?>
                    }"
                        class="p-4 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded-lg shadow space-y-3">
                        <label class="block text-sm mb-1 text-stone-600 dark:text-gray-300">Carpeta en Drive</label>

                        <div class="overflow-y-auto max-h-80 rounded border border-gray-200 dark:border-gray-700 p-3">
                            <ul class="space-y-1">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $arbolCarpetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if (isset($component)) { $__componentOriginalecb063f81f69887b8a5f41a9b9c96880 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arbol-carpetas-nodo','data' => ['nodo' => $nodo,'nivel' => 0,'model' => 'carpeta_drive_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arbol-carpetas-nodo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nodo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nodo),'nivel' => 0,'model' => 'carpeta_drive_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $attributes = $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $component = $__componentOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>

                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['carpeta_drive_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    

                    <div class="mt-6 flex justify-end space-x-2">
                        <button type="button" wire:click="cerrarModal"
                            class="px-4 py-2 bg-gray-300 dark:bg-gray-700 text-black dark:text-white rounded hover:bg-gray-400">Cancelar</button>
                        <button type="submit"
                            class="px-4 py-2 bg-amber-600 text-white rounded hover:bg-amber-700">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/control/tareas-asignadas.blade.php ENDPATH**/ ?>