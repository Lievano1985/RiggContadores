

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'confirmingDelete' => false, 
    'action' => '',
    'titulo' => 'Confirmar eliminación',
    'mensaje' => '¿Estás seguro de que lo quieres eliminar? Esta acción no se puede deshacer.',
    'tareas' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'confirmingDelete' => false, 
    'action' => '',
    'titulo' => 'Confirmar eliminación',
    'mensaje' => '¿Estás seguro de que lo quieres eliminar? Esta acción no se puede deshacer.',
    'tareas' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!--[if BLOCK]><![endif]--><?php if($confirmingDelete): ?>
<div class="fixed inset-0 flex items-center justify-center z-50 bg-black/70">
    <div class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg max-w-md w-full space-y-4">

        <h2 class="text-lg font-semibold text-stone-600 dark:text-white"><?php echo e($titulo); ?></h2>
        <p class="text-gray-700 dark:text-gray-300"><?php echo e($mensaje); ?></p>

        <!--[if BLOCK]><![endif]--><?php if(!empty($tareas)): ?>
            <div class="border border-red-300 dark:border-red-600 p-3 rounded bg-red-50 dark:bg-red-900/30">
                <p class="text-sm text-red-700 dark:text-red-300 font-semibold mb-2">Tareas relacionadas:</p>
                <ul class="list-disc list-inside text-sm text-gray-700 dark:text-gray-300 max-h-40 overflow-auto">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($tarea->tareaCatalogo->nombre ?? 'Tarea sin nombre'); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="flex justify-end space-x-2">
            <button wire:click="$set('confirmarEliminacion', false)"
                    class="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-black dark:text-white rounded hover:bg-gray-400">
                Cancelar
            </button>
            <button wire:click="<?php echo e($action); ?>"
                    class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
                Eliminar
            </button>
        </div>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/components/confirmacion-eliminacion.blade.php ENDPATH**/ ?>