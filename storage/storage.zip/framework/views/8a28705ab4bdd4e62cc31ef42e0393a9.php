<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'nodo' => [],        // ['id','nombre','parent_id','children'=>[]]
    'nivel' => 0,
    'model' => 'carpeta_drive_id', // usado para name del radio
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'nodo' => [],        // ['id','nombre','parent_id','children'=>[]]
    'nivel' => 0,
    'model' => 'carpeta_drive_id', // usado para name del radio
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $iconos = ['📁','📂','🗂','🗃'];
    $icono = $iconos[min($nivel, count($iconos)-1)];
    $indent = str_repeat('— ', max(0, $nivel - 1));
?>

<li class="p-2 rounded odd:bg-gray-50 even:bg-white dark:odd:bg-gray-800 dark:even:bg-gray-900">
    <div class="flex items-center justify-between">
        <label class="flex items-center gap-2 cursor-pointer">
            
            <input
                type="radio"
                name="<?php echo e($model); ?>"
                x-model="seleccion"
                value="<?php echo e($nodo['id']); ?>"
                class="accent-amber-600"
            >
            <span class="text-sm <?php echo e($nivel === 0 ? 'font-semibold' : ''); ?>">
                <?php echo e($indent); ?><?php echo e($icono); ?> <?php echo e($nodo['nombre']); ?>

            </span>
        </label>

        <!--[if BLOCK]><![endif]--><?php if(!empty($nodo['children'])): ?>
            <button
                type="button"
                class="text-xs text-amber-600 hover:underline"
                @click="abiertos['<?php echo e($nodo['id']); ?>'] = !abiertos['<?php echo e($nodo['id']); ?>']">
                <span x-show="!abiertos['<?php echo e($nodo['id']); ?>']">Mostrar</span>
                <span x-show="abiertos['<?php echo e($nodo['id']); ?>']">Ocultar</span>
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!--[if BLOCK]><![endif]--><?php if(!empty($nodo['children'])): ?>
        <ul
            class="pl-4 border-l border-gray-300 dark:border-gray-700 mt-1 space-y-1"
            x-show="abiertos['<?php echo e($nodo['id']); ?>']"
            x-transition
        >
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $nodo['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalecb063f81f69887b8a5f41a9b9c96880 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arbol-carpetas-nodo','data' => ['nodo' => $hijo,'nivel' => $nivel+1,'model' => $model]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arbol-carpetas-nodo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nodo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($hijo),'nivel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nivel+1),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($model)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $attributes = $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $component = $__componentOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</li>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/components/arbol-carpetas-nodo.blade.php ENDPATH**/ ?>