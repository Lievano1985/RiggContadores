<div>
<div class="p-6 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded-lg shadow space-y-4">

    <h2 class="text-xl font-bold text-stone-600">Mis obligaciones asignadas</h2>

    <div class="flex items-center justify-between">
    
        <div class="flex items-center gap-2">
            <input type="text" placeholder="Buscar (cliente/obligación)"
                wire:model.live="buscar"
                class="w-64 px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
    
            <select wire:model.live="estatus"
                class="px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                <option value="">Estatus (todos)</option>
                <option value="asignada">Asignada</option>
                <option value="iniciando">Iniciando</option>
                <option value="declaracion_realizada">Declaración realizada</option>
                <option value="enviada_cliente">Enviada a cliente</option>
                <option value="respuesta_cliente">Respuesta de cliente</option>
                <option value="respuesta_revisada">Respuesta revisada</option>
                <option value="finalizado">Finalizado</option>
                <option value="reabierta">Reabierta</option>
            </select>
    
            <input type="date" wire:model.live="vence_desde"
                class="px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline"
                title="Vence desde">
    
            <input type="date" wire:model.live="vence_hasta"
                class="px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline"
                title="Vence hasta">
        </div>
    </div>
    
  
    <div class="overflow-x-auto rounded shadow">
        <table class="min-w-full divide-y divide-gray-300 dark:divide-gray-700">
            <thead class="bg-stone-100 dark:bg-stone-900">
                <tr>
                    <th class="px-4 py-2 text-left">Cliente</th>
                    <th class="px-4 py-2 text-left">Obligación</th>
                    <th class="px-4 py-2 text-left">Estatus</th>
                    <th class="px-4 py-2 text-left">Vence</th>
                    <th class="px-4 py-2 text-left">Inicio</th>
                    <th class="px-4 py-2 text-center">Acción</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-800">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-2"><?php echo e($item->cliente->nombre); ?></td>
                        <td class="px-4 py-2"><?php echo e($item->obligacion->nombre); ?></td>
                        <td class="px-4 py-2">
                            <span class="text-xs px-2 py-1 rounded bg-stone-600 text-white">
                                <?php echo e(ucfirst(str_replace('_', ' ', $item->estatus))); ?>

                            </span>
                            <!--[if BLOCK]><![endif]--><?php if(property_exists($item, 'bloqueada_por_tareas') && $item->bloqueada_por_tareas): ?>
                                <span class="ml-2 text-xs px-2 py-1 rounded bg-amber-600 text-white" title="Tiene tareas pendientes">
                                    tareas pendientes
                                </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td class="px-4 py-2">
                            <?php echo e($item->fecha_vencimiento ? \Carbon\Carbon::parse($item->fecha_vencimiento)->format('d/m/Y') : '–'); ?>

                        </td>
                        <td class="px-4 py-2">
                            <?php echo e($item->fecha_inicio ? \Carbon\Carbon::parse($item->fecha_inicio)->format('d/m/Y H:i') : '–'); ?>

                        </td>
                        <td class="px-4 py-2 text-center space-x-2">
                            <!--[if BLOCK]><![endif]--><?php if($item->estatus === 'asignada'): ?>
                                <button wire:click="iniciarObligacion(<?php echo e($item->id); ?>)"
                                    class="px-3 py-1 bg-amber-600 text-white rounded hover:bg-amber-700">
                                    Iniciar
                                </button>
                            <?php elseif($item->estatus === 'en_progreso'): ?>
                                <button wire:click="openResultModal(<?php echo e($item->id); ?>)"
                                    class="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700">
                                    Subir resultados
                                </button>
                            <?php elseif($item->estatus === 'realizada'): ?>
                                <button wire:click="openResultModal(<?php echo e($item->id); ?>)"
                                    class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
                                    Editar resultados
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <?php echo e($obligaciones->links()); ?>


    <!--[if BLOCK]><![endif]--><?php if($openModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-stone-600/50 z-50">

            <div class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg w-full max-w-lg">
                <h3 class="text-lg font-bold mb-4 text-stone-600">Subir resultados</h3>

                <div class="space-y-4">
                    <div>
                        <label class="block mb-1">Archivo</label>
                        <input type="file" wire:model="archivo"
                            class="w-full border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['archivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($selectedObligacion?->archivo_resultado && Storage::disk('public')->exists($selectedObligacion->archivo_resultado)): ?>
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            📄 Archivo actual:
                            <a href="<?php echo e(Storage::disk('public')->url($selectedObligacion->archivo_resultado)); ?>"
                               target="_blank" class="text-amber-600 hover:underline">
                               Ver archivo actual
                            </a>
                        </p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    
                    <!--[if BLOCK]><![endif]--><?php if(!empty($selectedObligacion?->archivo_resultado_drive)): ?>
                        <p class="text-sm">
                            ☁️ En Drive:
                            <a href="<?php echo e($selectedObligacion->archivo_resultado_drive); ?>" target="_blank"
                               class="text-amber-600 hover:underline">Abrir en Drive</a>
                        </p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div>
                        <label class="block mb-1">Número de operación</label>
                        <input type="text" wire:model.defer="numero_operacion"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['numero_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div>
                        <label class="block mb-1">Fecha de vencimiento</label>
                        <input type="date" wire:model.defer="fecha_vencimiento"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_vencimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="flex justify-end space-x-2 mt-6">
                    <button wire:click="$set('openModal', false)"
                        class="bg-gray-300 dark:bg-gray-600 px-4 py-2 rounded text-black dark:text-white hover:bg-gray-400">
                        Cancelar
                    </button>
                    <button wire:click="saveResult"
                        class="bg-amber-600 hover:bg-amber-700 px-4 py-2 rounded text-white">
                        Guardar
                    </button>
                </div>
            </div>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
    <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show"
        x-transition:leave="transition ease-in duration-500"
        x-transition:leave-start="opacity-100 transform translate-y-0"
        x-transition:leave-end="opacity-0 transform -translate-y-10"
        class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-red-800 bg-red-200 rounded-lg shadow-lg dark:bg-red-200 dark:text-red-900">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php if(session()->has('success')): ?>
<div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show"
    x-transition:leave="transition ease-in duration-500"
    x-transition:leave-start="opacity-100 transform translate-y-0"
    x-transition:leave-end="opacity-0 transform -translate-y-10"
    class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php if (isset($component)) { $__componentOriginalf26909af655deaf31c8e20175813a5a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf26909af655deaf31c8e20175813a5a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spinner','data' => ['target' => 'saveResult']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => 'saveResult']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $attributes = $__attributesOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__attributesOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $component = $__componentOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__componentOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/contador/obligaciones-index.blade.php ENDPATH**/ ?>