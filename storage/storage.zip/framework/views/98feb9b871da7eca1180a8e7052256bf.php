<div class="p-6 bg-white dark:bg-gray-900 rounded-lg shadow">



    
    <div class="flex justify-between items-center">
        <h2 class="text-xl font-bold text-stone-600">Obligaciones asignadas</h2>
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <!--[if BLOCK]><![endif]--><?php if($asignacionCompleta): ?>
                    <span class="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">✔ Completo</span>
               <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        
            <!--[if BLOCK]><![endif]--><?php if (! ($asignacionCompleta)): ?>
                <button wire:click="mostrarModalCrear"
                    class="bg-amber-950 text-white px-4 py-2 rounded hover:bg-amber-700">
                    + Asignar obligación
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        
    </div>

    
    <table class="min-w-full divide-y divide-gray-300 dark:divide-gray-700 text-sm">
        <thead class="bg-stone-100 dark:bg-stone-900">
            <tr>
                <th class="px-4 py-2 text-left">Obligación</th>
                <th class="px-4 py-2 text-left">Carpeta en Drive</th>
                <th class="px-4 py-2 text-left">Contador</th>
                <th class="px-4 py-2 text-left">Fecha límite</th>
                <th class="px-4 py-2 text-left">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t dark:border-stone-700">
                    <td class="px-4 py-2"><?php echo e($asignacion->obligacion->nombre); ?></td>
                    <td class="px-4 py-2"><?php echo e($asignacion->carpeta?->nombre ?? 'Sin carpeta'); ?></td>
                    <td class="px-4 py-2"><?php echo e($asignacion->contador->name); ?></td>
                    <td class="px-4 py-2"><?php echo e($asignacion->fecha_vencimiento ?? 'Sin fecha'); ?></td>
                    <td class="px-4 py-2 space-x-2">
                        <button wire:click="editarAsignacion(<?php echo e($asignacion->id); ?>)"
                            class="text-amber-700 hover:underline">Editar</button>


                        <button wire:click="confirmarEliminacionAsignacion(<?php echo e($asignacion->id); ?>)"
                            class="text-red-600 hover:underline">
                            Eliminar
                        </button>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-4 py-2 text-center text-stone-500">No hay asignaciones registradas.
                    </td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    
    <!--[if BLOCK]><![endif]--><?php if($modalVisible): ?>
        <div class="fixed inset-0 flex items-center justify-center z-50 bg-stone-600 bg-opacity-50">
            <div
                class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg w-full max-w-3xl overflow-y-auto max-h-[90vh]">
                <h3 class="text-lg font-bold text-stone-600 mb-4">
                    <?php echo e($modoEdicion ? 'Editar obligación asignada' : 'Asignar nueva obligación'); ?>

                </h3>

                <div wire:key="form-<?php echo e($formKey); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    <div class="space-y-1">
                        <label class="block text-sm font-semibold text-stone-600">Obligación</label>

                        <!--[if BLOCK]><![endif]--><?php if($modoEdicion): ?>
                            <p
                                class="text-sm text-gray-800 dark:text-white px-3 py-2 bg-gray-100 dark:bg-gray-800 border border-gray-300 rounded">
                                <?php echo e($asignaciones->firstWhere('obligacion_id', $obligacion_id)?->obligacion?->nombre ?? 'Sin nombre'); ?>

                            </p>
                        <?php else: ?>
                            <select wire:model.live="obligacion_id"
                                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                                <option value="">-- Selecciona una obligación --</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligacionesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($o->id); ?>"><?php echo e($o->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['obligacion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    
                    <div class="space-y-1">
                        <label class="block text-sm font-semibold text-stone-600">Contador</label>
                        <select wire:model.live="contador_id"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                            <option value="">-- Selecciona un contador --</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contador_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    
                    <div class="space-y-1">
                        <label class="block text-sm font-semibold text-stone-600">Vencimiento</label>
                        <input type="date" wire:model.live="fecha_vencimiento"
                            class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_vencimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                
                <div class="mt-6">
                    <label class="block text-sm font-semibold text-stone-600 mb-2">Carpeta en Drive</label>
                    <div x-data="{
                        abiertos: {},
                        seleccion: <?php if ((object) ('carpeta_drive_id') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('carpeta_drive_id'->value()); ?>')<?php echo e('carpeta_drive_id'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('carpeta_drive_id'); ?>')<?php endif; ?>
                    }"
                        class="overflow-y-auto max-h-80 rounded border border-gray-200 dark:border-gray-700 p-3">
                        <ul class="space-y-1">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $arbolCarpetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginalecb063f81f69887b8a5f41a9b9c96880 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arbol-carpetas-nodo','data' => ['nodo' => $nodo,'nivel' => 0,'model' => 'carpeta_drive_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arbol-carpetas-nodo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nodo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nodo),'nivel' => 0,'model' => 'carpeta_drive_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $attributes = $__attributesOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__attributesOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880)): ?>
<?php $component = $__componentOriginalecb063f81f69887b8a5f41a9b9c96880; ?>
<?php unset($__componentOriginalecb063f81f69887b8a5f41a9b9c96880); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['carpeta_drive_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="mt-6 flex justify-end space-x-2">
                    <button wire:click="$set('modalVisible', false)"
                        class="bg-gray-300 dark:bg-gray-600 text-black dark:text-white px-4 py-2 rounded hover:bg-gray-400">
                        Cancelar
                    </button>
                    <button wire:click="guardar" class="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800">
                        <?php echo e($modoEdicion ? 'Actualizar' : 'Asignar'); ?>

                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if (isset($component)) { $__componentOriginal35286cb5f40220d929e1df7cf775f365 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35286cb5f40220d929e1df7cf775f365 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmacion-eliminacion','data' => ['confirmingDelete' => $confirmarEliminacion,'action' => 'eliminarAsignacionConfirmada','titulo' => 'Eliminar obligación asignada','mensaje' => 'Esta obligación tiene tareas asignadas. Si la eliminas, también se eliminarán las tareas relacionadas.','tareas' => $tareasRelacionadas]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirmacion-eliminacion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['confirming-delete' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($confirmarEliminacion),'action' => 'eliminarAsignacionConfirmada','titulo' => 'Eliminar obligación asignada','mensaje' => 'Esta obligación tiene tareas asignadas. Si la eliminas, también se eliminarán las tareas relacionadas.','tareas' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tareasRelacionadas)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35286cb5f40220d929e1df7cf775f365)): ?>
<?php $attributes = $__attributesOriginal35286cb5f40220d929e1df7cf775f365; ?>
<?php unset($__attributesOriginal35286cb5f40220d929e1df7cf775f365); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35286cb5f40220d929e1df7cf775f365)): ?>
<?php $component = $__componentOriginal35286cb5f40220d929e1df7cf775f365; ?>
<?php unset($__componentOriginal35286cb5f40220d929e1df7cf775f365); ?>
<?php endif; ?>

    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show"
            x-transition:leave="transition ease-in duration-500"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform -translate-y-10"
            class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/control/obligaciones-asignadas.blade.php ENDPATH**/ ?>