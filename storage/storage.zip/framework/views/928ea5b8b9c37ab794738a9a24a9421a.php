<div class="p-6 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded-lg shadow space-y-4">
    <div class="mb-4">
        <div wire:key="modo-<?php echo e($modoKey); ?>">

        <label class="inline-flex items-center cursor-pointer">
            <input type="checkbox" wire:model.live="modoEdicion" class="sr-only peer">
            <div
                class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 dark:peer-focus:ring-amber-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-amber-600 dark:peer-checked:bg-amber-600">
            </div>
            <span class="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Modo edición</span>
        </label>
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($modoEdicion): ?>
        <form wire:submit.prevent="guardar" class="space-y-6">

                <div x-data="{ expanded: true }" class="py-2 border-b-1">
                    <h2>
                        <button id="faqs-title-01"type="button"
                            class="flex items-center justify-between w-full text-left font-semibold py-2"
                            @click="expanded = !expanded" :aria-expanded="expanded" aria-controls="faqs-text-01">
                            <span>Regímenes fiscales</span>
                            <svg class="fill-indigo-500 shrink-0 ml-8" width="16" height="16"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center rotate-90 transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                            </svg>
                        </button>
                    </h2>
                    <div id="faqs-text-01" role="region" aria-labelledby="faqs-title-01"
                        class="grid text-sm text-slate-600 overflow-hidden transition-all duration-300 ease-in-out"
                        :class="expanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            
                            <div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $regimenesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regimen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center space-x-2">
                                            <input type="checkbox" value="<?php echo e($regimen->id); ?>"
                                                wire:model="regimenesSeleccionados"
                                                class="rounded border-gray-300 dark:bg-gray-700 dark:border-gray-600 text-amber-600 focus:ring-amber-500">
                                            <span><?php echo e($regimen->nombre); ?></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Accordion item -->


                </div>
                

                <div x-data="{ expanded: false }" class="py-2 border-b-1">
                    <h2>
                        <button id="faqs-title-01"type="button"
                            class="flex items-center justify-between w-full text-left font-semibold py-2"
                            @click="expanded = !expanded" :aria-expanded="expanded" aria-controls="faqs-text-01">
                            <span>Actividades económicas
                            </span>
                            <svg class="fill-indigo-500 shrink-0 ml-8" width="16" height="16"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center rotate-90 transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                            </svg>
                        </button>
                    </h2>
                    <div id="faqs-text-01" role="region" aria-labelledby="faqs-title-01"
                        class="grid text-sm text-slate-600 overflow-hidden transition-all duration-300 ease-in-out"
                        :class="expanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            <div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $actividadesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center space-x-2">
                                            <input type="checkbox" value="<?php echo e($actividad->id); ?>"
                                                wire:model="actividadesSeleccionadas"
                                                class="rounded border-gray-300 dark:bg-gray-700 dark:border-gray-600 text-amber-600 focus:ring-amber-500">
                                            <span><?php echo e($actividad->nombre); ?></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Accordion item -->


                </div>
                <div x-data="{ expanded: false }" class="py-2 border-b-1">
                    <h2>
                        <button id="faqs-title-01"type="button"
                            class="flex items-center justify-between w-full text-left font-semibold py-2"
                            @click="expanded = !expanded" :aria-expanded="expanded" aria-controls="faqs-text-01">
                            <span>Obligaciones fiscales</span>
                            <svg class="fill-indigo-500 shrink-0 ml-8" width="16" height="16"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                                <rect y="7" width="16" height="2" rx="1"
                                    class="transform origin-center rotate-90 transition duration-200 ease-out"
                                    :class="{ '!rotate-180': expanded }" />
                            </svg>
                        </button>
                    </h2>
                    <div id="faqs-text-01" role="region" aria-labelledby="faqs-title-01"
                        class="grid text-sm text-slate-600 overflow-hidden transition-all duration-300 ease-in-out"
                        :class="expanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $obligacionesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obligacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center space-x-2">
                                        <input type="checkbox" value="<?php echo e($obligacion->id); ?>" wire:model="obligacionesSeleccionadas"
                                            class="rounded border-gray-300 text-amber-600 focus:ring-amber-500">
                                        <span><?php echo e($obligacion->nombre); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                    <!-- Accordion item -->


                </div>
                <div class="flex justify-end space-x-2">
                    <button type="submit" class="px-4 py-2 bg-amber-950 hover:bg-amber-700 text-white rounded">
                        Guardar cambios
                    </button>
                </div>
        </form>
    <?php else: ?>
        
        <div>
            <h3 class="text-md font-semibold text-stone-600 mb-2">Regímenes fiscales seleccionados</h3>
            <ul class="list-disc list-inside text-sm text-gray-800 dark:text-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cliente->regimenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regimen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><?php echo e($regimen->nombre); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-gray-500">Sin seleccionar</li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>

        <div>
            <h3 class="text-md font-semibold text-stone-600 mb-2">Actividades económicas seleccionadas</h3>
            <ul class="list-disc list-inside text-sm text-gray-800 dark:text-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cliente->actividadesEconomicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><?php echo e($actividad->nombre); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-gray-500">Sin seleccionar</li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>

        <div>
            <h3 class="text-md font-semibold text-stone-600 mb-2">Obligaciones fiscales seleccionadas</h3>
            <ul class="list-disc list-inside text-sm text-gray-800 dark:text-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cliente->obligaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obligacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><?php echo e($obligacion->nombre); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-gray-500">Sin seleccionar</li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 3000)" x-show="show"
        x-transition:leave="transition ease-in duration-500"
        x-transition:leave-start="opacity-100 transform translate-y-0"
        x-transition:leave-end="opacity-0 transform -translate-y-10"
        class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/clientes/datos-fiscales.blade.php ENDPATH**/ ?>