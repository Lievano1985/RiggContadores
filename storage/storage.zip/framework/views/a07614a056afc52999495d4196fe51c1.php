

<img src="/img/logo.png" class="h-20" alt="Flowbite Logo">
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>