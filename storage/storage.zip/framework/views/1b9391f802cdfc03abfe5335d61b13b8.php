<div class="p-6 dark:bg-gray-900 bg-white text-gray-900 dark:text-white">

    <!-- Título y Botón Crear Cliente -->
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold text-stone-600">Clientes</h2>

        <button wire:click="abrirModalCrear" class="px-4 py-2 bg-amber-950 text-white rounded hover:bg-amber-700">
            + Crear Cliente
        </button>
    </div>

    <!-- Tabla de clientes -->
    <div class="overflow-x-auto rounded shadow">
        <table class="min-w-full divide-y divide-gray-300 dark:divide-gray-700">
            <thead class="bg-stone-100 dark:bg-stone-900">
                <tr>
                    <th class="px-4 py-2 text-left">Nombre</th>
                    <th class="px-4 py-2 text-left">RFC</th>
                    <th class="px-4 py-2 text-left">Teléfono</th>
                    <th class="px-4 py-2 text-left">Correo</th>
                    <th class="px-4 py-2 text-left">Tipo</th>
                    <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('super_admin')): ?>
                        <th class="px-4 py-2 text-left">Despacho</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <th class="px-4 py-2 text-left">Acciones</th>
                    <th class="px-4 py-2 text-left">Asignaciones</th>

                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-2"><?php echo e($cliente->nombre); ?></td>
                        <td class="px-4 py-2"><?php echo e($cliente->rfc); ?></td>
                        <td class="px-4 py-2"><?php echo e($cliente->telefono); ?></td>
                        <td class="px-4 py-2"><?php echo e($cliente->correo); ?></td>
                        <td class="px-4 py-2 capitalize"><?php echo e(str_replace('_', ' ', $cliente->tipo_persona)); ?></td>
                        <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('super_admin')): ?>
                            <td class="px-4 py-2"><?php echo e($cliente->despacho->nombre ?? '-'); ?></td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <td class="px-4 py-2 space-x-2">
                           
                            <button wire:click="confirmarEliminar(<?php echo e($cliente->id); ?>)"
                                class="text-red-600 hover:underline">Eliminar</button>
                            <a href="<?php echo e(route('clientes.expediente.show', $cliente->id)); ?>"
                               class="text-green-600 hover:underline">Expediente</a>
                               
                        </td>
                        <td class="px-4 py-2">
                            <!--[if BLOCK]><![endif]--><?php if($cliente->asignaciones_completas): ?>
                               
                                <span class="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">✔ Completo</span>

                            <?php else: ?>
                            <span class="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">⚠  Incompleto</span>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-4 py-4 text-center text-gray-500 dark:text-gray-400">
                            No hay clientes registrados.
                        </td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <div class="mt-4">
        <?php echo e($clientes->links()); ?>

    </div>

    <!-- Modal Crear/Editar -->
    <!--[if BLOCK]><![endif]--><?php if($modalFormVisible): ?>
    <div class="fixed inset-0 flex items-center justify-center bg-stone-600/70 z-50">
        <div class="bg-white dark:bg-gray-900 text-gray-900 dark:text-white p-6 rounded-lg w-full max-w-2xl shadow-lg overflow-y-auto max-h-[90vh]">
            <h3 class="text-lg font-semibold mb-4 text-stone-600">
                <?php echo e($clienteId ? 'Editar Cliente' : 'Crear Cliente'); ?>

            </h3>

            <form wire:submit.prevent="guardar" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm mb-1">Nombre comercial</label>
                        <input type="text" wire:model.defer="nombre" 
                        class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline focus:outline" 
                        oninput="this.value = this.value.toUpperCase()" required>
                    </div>
                    <div>
                        <label class="block text-sm mb-1">Razón social</label>
                        <input type="text" wire:model.defer="razon_social" 
                        class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline focus:outline" 
                        oninput="this.value = this.value.toUpperCase()" required>
                    </div>

                    <div>
                        <label class="block text-sm mb-1">RFC</label>
                        <input type="text" wire:model.defer="rfc" 
                        class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline focus:outline" 
                        oninput="this.value = this.value.toUpperCase()" required>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div>
                        <label class="block text-sm mb-1">CURP</label>
                        <input type="text" wire:model.defer="curp"
                        class="uppercase w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline focus:outline" 
                        oninput="this.value = this.value.toUpperCase()" >
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['curp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div>
                        <label class="block text-sm mb-1">Correo</label>
                        <input type="email" wire:model.defer="correo" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline" required>
                    </div>
                    <div>
                        <label class="block text-sm mb-1">Teléfono</label>
                        <input type="text" wire:model.defer="telefono" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:outline-amber-600 focus:outline">
                    </div>

                  

                    <div>
                        <label class="block text-sm mb-1">Tipo de Persona</label>
                        <select wire:model.defer="tipo_persona" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:border-amber-600 focus:outline-none" required>
                            <option value="">-- Selecciona --</option>
                            <option value="fisica">Persona Física</option>
                            <option value="moral">Persona Moral</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm mb-1">Tiene trabajadores</label>
                        <select wire:model.defer="tiene_trabajadores" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white focus:border-amber-600 focus:outline-none">
                            <option value="1">Sí</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                <div class="flex justify-end space-x-2 mt-6">
                    <button type="button" wire:click="$set('modalFormVisible', false)"
                            class="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-black dark:text-white rounded hover:bg-gray-400">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 bg-stone-600 text-white rounded hover:bg-stone-700">
                        Guardar
                    </button>
                </div>
            </form>
            <div wire:loading wire:target="guardar" class="absolute inset-0 flex items-center justify-center bg-black/75 dark:bg-gray-900/75 rounded-lg z-50">
                <div class="flex flex-col items-center space-y-2">
                    <svg class="animate-spin h-8 w-8 text-amber-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 01-8 8z"/>
                    </svg>
                    <p class="text-stone-600 dark:text-white">Guardando cliente y creando carpetas...</p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($confirmingDelete): ?>
    <div class="fixed inset-0 flex items-center justify-center bg-stone-600/70 z-50">
        <div class="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg border border-amber-900 text-center w-full max-w-md mx-auto">
            <p class="text-stone-600 dark:text-white text-lg font-semibold mb-4">
                ¿Estás seguro que deseas eliminar este cliente?
            </p>
            <div class="flex justify-center space-x-4">
                <button wire:click="eliminar"
                        class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
                    Sí, eliminar
                </button>
                <button wire:click="$set('confirmingDelete', false)"
                        class="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-black dark:text-white rounded hover:bg-gray-400">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
<div
    x-data="{ show: true }"
    x-init="setTimeout(() => show = false, 3000)"
    x-show="show"
    x-transition:leave="transition ease-in duration-500"
    x-transition:leave-start="opacity-100 transform translate-y-0"
    x-transition:leave-end="opacity-0 transform -translate-y-10"
    class="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-sm p-4 text-sm text-green-800 bg-green-200 rounded-lg shadow-lg dark:bg-green-200 dark:text-green-900"
>
 <?php echo e(session('message')); ?>

</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\riggcontadores\resources\views/livewire/clientes/clientes-index.blade.php ENDPATH**/ ?>